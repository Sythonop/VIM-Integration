class ZCL_ACE_TABLE_VIEWER definition
  public
  inheriting from ZCL_ACE_POPUP
  create public .

public section.

  types:
    BEGIN OF t_elem,
               field TYPE fieldname,
               elem  TYPE ddobjname,
             END OF t_elem .

  data M_LANG type DDLANGUAGE .
  data M_TABNAME type TABNAME .
  data MO_ALV type ref to CL_GUI_ALV_GRID .
  data MO_SEL type ref to ZCL_ACE_SEL_OPT .
  data MR_TABLE type ref to DATA .
  data MO_SEL_PARENT type ref to CL_GUI_CONTAINER .
  data MO_ALV_PARENT type ref to CL_GUI_CONTAINER .
  data MT_ALV_CATALOG type LVC_T_FCAT .
  data:
    mt_fields          TYPE TABLE OF t_elem .
  data MO_SEL_WIDTH type I .
  data M_VISIBLE type C .
  data M_STD_TBAR type X .
  data M_SHOW_EMPTY type I .
  data MO_WINDOW type ref to ZCL_ACE_WINDOW .

  methods CONSTRUCTOR
    importing
      !I_TNAME type ANY optional
      !I_ADDITIONAL_NAME type STRING optional
      !IR_TAB type ref to DATA optional
      !IO_WINDOW type ref to ZCL_ACE_WINDOW .
  methods REFRESH_TABLE
    for event SELECTION_DONE of ZCL_ACE_SEL_OPT .
  CLASS-METHODS open_int_table
    IMPORTING
      !it_tab    TYPE ANY TABLE OPTIONAL
      !it_ref    TYPE REF TO data OPTIONAL
      !i_name    TYPE string
      !io_window TYPE REF TO zcl_ace_window .
protected section.
private section.

  methods CREATE_POPUP .
  methods CREATE_ALV .
  methods CREATE_SEL_ALV .
  methods SET_HEADER .
  methods CREATE_FIELD_CAT
    importing
      !I_TNAME type TABNAME
    returning
      value(ET_CATALOG) type LVC_T_FCAT .
  methods TRANSLATE_FIELD
    importing
      !I_LANG type DDLANGUAGE
    changing
      !C_FLD type LVC_S_FCAT .
  methods HANDLE_TAB_TOOLBAR
    for event TOOLBAR of CL_GUI_ALV_GRID
    importing
      !E_OBJECT .
  methods BEFORE_USER_COMMAND
    for event BEFORE_USER_COMMAND of CL_GUI_ALV_GRID
    importing
      !E_UCOMM .
  methods HANDLE_USER_COMMAND
    for event USER_COMMAND of CL_GUI_ALV_GRID
    importing
      !E_UCOMM .
  methods ON_TABLE_CLOSE
    for event CLOSE of CL_GUI_DIALOGBOX_CONTAINER
    importing
      !SENDER .
ENDCLASS.



CLASS ZCL_ACE_TABLE_VIEWER IMPLEMENTATION.


  method BEFORE_USER_COMMAND.


      CASE e_ucomm.
        WHEN '&INFO'.
          DATA(l_url) = 'https://ysychov.wordpress.com/2020/02/10/simple-data-explorer/'.
          CALL FUNCTION 'CALL_BROWSER' EXPORTING url = l_url.
      ENDCASE.


  endmethod.


  method CONSTRUCTOR.


      DATA: comp         TYPE abap_componentdescr,
            comp_notab   TYPE abap_component_tab,
            comp_tab2str TYPE abap_component_tab,
            comp_str     TYPE abap_component_tab,
            str          TYPE string,
            data         TYPE REF TO data.

      DATA: l_notab   TYPE REF TO data,
            l_tab2str TYPE REF TO data.

      DATA: handle_notab   TYPE REF TO cl_abap_structdescr,
            handle_tab2str TYPE REF TO cl_abap_structdescr,
            o_new_tab      TYPE REF TO cl_abap_tabledescr.

      FIELD-SYMBOLS: <notab>   TYPE STANDARD TABLE,
                     <tab2str> TYPE STANDARD TABLE,
                     <any_tab> TYPE ANY TABLE,
                     <temptab> TYPE ANY TABLE.

      super->constructor( i_additional_name = i_additional_name ).
      mo_window = io_window.
      m_lang = sy-langu.
      mo_sel_width = 0.
      m_tabname = i_tname.
      create_popup( ).

      IF ir_tab IS NOT BOUND.
        ZCL_ACE_RTTI=>create_table_by_name( EXPORTING i_tname = m_tabname CHANGING c_table = mr_table ).
      ELSE.
        FIELD-SYMBOLS:<any> TYPE any.
        ASSIGN ir_tab->* TO <any>.
        DATA o_tabl  TYPE REF TO cl_abap_tabledescr.
        DATA o_struc TYPE REF TO cl_abap_structdescr.
        o_tabl ?= cl_abap_typedescr=>describe_by_data( <any> ).
        TRY.
            o_struc ?= o_tabl->get_table_line_type( ).
            ASSIGN ir_tab->* TO <any_tab>.
            TRY.
                LOOP AT o_struc->components INTO DATA(component).

                  IF component-type_kind NE 'h'.
                    comp-name = component-name.
                    comp-type ?= o_struc->get_component_type( component-name ).
                    APPEND comp TO comp_notab.
                    APPEND comp TO comp_tab2str.
                  ELSE.
                    comp-name = component-name.
                    comp-type ?= cl_abap_typedescr=>describe_by_data(  str ).
                    APPEND comp TO comp_tab2str.
                    APPEND comp TO comp_str.

                    comp-name = component-name && '_REF'.
                    comp-type ?= cl_abap_typedescr=>describe_by_data(  data ).
                    APPEND comp TO comp_tab2str.
                  ENDIF.
                ENDLOOP.
              CATCH cx_sy_move_cast_error.
            ENDTRY.

            TRY.
                handle_notab  = cl_abap_structdescr=>create( comp_notab ).
                handle_tab2str  = cl_abap_structdescr=>create( comp_tab2str ).

                o_new_tab = cl_abap_tabledescr=>create(
                  p_line_type  = handle_notab
                  p_table_kind = cl_abap_tabledescr=>tablekind_std
                  p_unique     = abap_false ).

                CREATE DATA l_notab TYPE HANDLE o_new_tab.

                o_new_tab = cl_abap_tabledescr=>create(
                  p_line_type  = handle_tab2str
                  p_table_kind = cl_abap_tabledescr=>tablekind_std
                  p_unique     = abap_false ).

                CREATE DATA l_tab2str TYPE HANDLE o_new_tab.

                ASSIGN l_notab->* TO <notab>.
                MOVE-CORRESPONDING <any_tab> TO <notab>.
                ASSIGN l_tab2str->* TO <tab2str>.
                MOVE-CORRESPONDING <notab> TO <tab2str>.

                LOOP AT <any_tab> ASSIGNING FIELD-SYMBOL(<old_struc>).
                  READ TABLE <tab2str> ASSIGNING FIELD-SYMBOL(<new_struc>) INDEX sy-tabix.
                  LOOP AT comp_str INTO comp.
                    ASSIGN COMPONENT comp-name OF STRUCTURE <new_struc> TO FIELD-SYMBOL(<field>).
                    ASSIGN COMPONENT comp-name OF STRUCTURE <old_struc> TO <temptab>.
                    <field> = | { icon_view_table } [{ lines( <temptab> ) }] |.
                    ASSIGN COMPONENT comp-name  OF STRUCTURE <old_struc> TO <field>.
                    ASSIGN COMPONENT |{ comp-name }_REF| OF STRUCTURE <new_struc> TO FIELD-SYMBOL(<ref>).
                    GET REFERENCE OF <field> INTO <ref>.
                  ENDLOOP.
                ENDLOOP.

                GET REFERENCE OF <tab2str> INTO mr_table.
              CATCH cx_root.
                mr_table = ir_tab.
            ENDTRY.
          CATCH cx_sy_move_cast_error.  "no structure
            comp-name = 'FIELD'.
            comp-type ?= cl_abap_typedescr=>describe_by_data( str ).
            APPEND comp TO comp_tab2str.

            handle_tab2str  = cl_abap_structdescr=>create( comp_tab2str ).
            o_new_tab = cl_abap_tabledescr=>create(
              p_line_type  = handle_tab2str
              p_table_kind = cl_abap_tabledescr=>tablekind_std
              p_unique     = abap_false ).

            CREATE DATA l_tab2str TYPE HANDLE o_new_tab.
            ASSIGN l_tab2str->* TO <tab2str>.
            ASSIGN ir_tab->* TO <any_tab>.

            LOOP AT <any_tab> ASSIGNING <old_struc>.
              APPEND INITIAL LINE TO <tab2str> ASSIGNING <new_struc>.
              ASSIGN COMPONENT 'FIELD' OF STRUCTURE <new_struc> TO <field>.
              <field> = <old_struc>.
            ENDLOOP.
            GET REFERENCE OF <tab2str> INTO mr_table.
        ENDTRY.
      ENDIF.

      create_alv( ).
      create_sel_alv( ).
      mo_alv->set_focus( mo_alv ).


  endmethod.


  method CREATE_ALV.


      DATA: layout TYPE lvc_s_layo,
            effect TYPE i,
            f4s    TYPE lvc_t_f4.

      FIELD-SYMBOLS: <f_tab>   TYPE table.

      mo_alv = NEW #( i_parent = mo_alv_parent ).
      mt_alv_catalog = create_field_cat( m_tabname ).

      IF mt_alv_catalog IS INITIAL.
        RETURN. "todo show tables without structure
      ENDIF.

      ASSIGN mr_table->* TO <f_tab>.
      set_header( ).
      layout-cwidth_opt = abap_true.
      layout-sel_mode = 'D'.



      SET HANDLER   before_user_command
                    handle_user_command
                    handle_tab_toolbar
                    FOR mo_alv.

      CALL METHOD mo_alv->set_table_for_first_display
        EXPORTING
          i_save          = abap_true
          i_default       = abap_true
          is_layout       = layout
        CHANGING
          it_fieldcatalog = mt_alv_catalog
          it_outtab       = <f_tab>.

      mo_alv->get_frontend_fieldcatalog( IMPORTING et_fieldcatalog = mt_alv_catalog ).
      LOOP AT mt_alv_catalog ASSIGNING FIELD-SYMBOL(<catalog>).
        CLEAR <catalog>-key.
        DATA(f4) = VALUE lvc_s_f4( register = abap_true chngeafter = abap_true fieldname = <catalog>-fieldname ).
        INSERT f4 INTO TABLE f4s.
      ENDLOOP.

      mo_alv->register_f4_for_fields( it_f4 = f4s ).
      mo_alv->set_frontend_fieldcatalog( EXPORTING it_fieldcatalog = mt_alv_catalog ).

      LOOP AT mt_alv_catalog ASSIGNING FIELD-SYMBOL(<cat>) WHERE scrtext_l IS INITIAL.
        ZCL_ACE_ALV_COMMON=>translate_field( CHANGING c_fld = <cat> ).
      ENDLOOP.

      mo_alv->set_frontend_fieldcatalog( EXPORTING it_fieldcatalog = mt_alv_catalog ).
      me->handle_user_command( EXPORTING e_ucomm = 'TECH' ).
      me->handle_user_command( EXPORTING e_ucomm = 'SHOW' ).
      mo_alv->set_toolbar_interactive( ).


  endmethod.


  method CREATE_FIELD_CAT.


      DATA: lr_field       TYPE REF TO data,
            lr_table_descr TYPE REF TO cl_abap_structdescr,
            lr_data_descr  TYPE REF TO cl_abap_datadescr,
            it_tabdescr    TYPE abap_compdescr_tab,
            l_texttab      TYPE tabname,
            lr_temp        TYPE REF TO data,
            l_name         TYPE string,
            l_dd04         TYPE dd04v.

      FIELD-SYMBOLS: <tab>   TYPE STANDARD TABLE,
                     <struc> TYPE any,
                     <field> TYPE any.

      ASSIGN mr_table->* TO <tab>.
      CREATE DATA lr_temp LIKE LINE OF <tab>.
      ASSIGN lr_temp->* TO <struc>.

      TRY.
          lr_table_descr ?= cl_abap_typedescr=>describe_by_data_ref( lr_temp ).
        CATCH cx_root.
          RETURN.
      ENDTRY.

      it_tabdescr[] = lr_table_descr->components[].

      LOOP AT it_tabdescr INTO DATA(ls)
         WHERE type_kind NE 'h'
           AND type_kind NE 'l'.
        DATA(l_ind) = sy-tabix.

        ASSIGN COMPONENT ls-name OF STRUCTURE <struc> TO <field>.
        GET REFERENCE OF <field> INTO lr_field.
        lr_data_descr ?= cl_abap_typedescr=>describe_by_data_ref( lr_field ).
        l_name = lr_data_descr->absolute_name.
        REPLACE ALL OCCURRENCES OF '\TYPE=' IN l_name WITH ''.
        APPEND VALUE #( field = ls-name elem = l_name ) TO mt_fields.

        CLEAR l_dd04.
        CALL FUNCTION 'DDIF_DTEL_GET'
          EXPORTING
            name          = CONV ddobjname( l_name )
            langu         = m_lang
          IMPORTING
            dd04v_wa      = l_dd04
          EXCEPTIONS
            illegal_input = 1
            OTHERS        = 2.

        APPEND INITIAL LINE TO et_catalog ASSIGNING FIELD-SYMBOL(<catalog>).

        <catalog>-col_pos = l_ind.
        <catalog>-style = ZCL_ACE_ALV_COMMON=>c_white.
        <catalog>-fieldname = ls-name.
        <catalog>-f4availabl = abap_true.

        IF l_dd04 IS INITIAL.
          <catalog>-scrtext_s = <catalog>-scrtext_m = <catalog>-scrtext_l = <catalog>-reptext = <catalog>-fieldname = ls-name.
        ELSE.
          MOVE-CORRESPONDING l_dd04 TO <catalog>.
        ENDIF.
      ENDLOOP.


  endmethod.


  method CREATE_POPUP.


      mo_box = create( i_width = 800 i_hight = 150 ).

      "save new popup ref
      APPEND INITIAL LINE TO ZCL_ACE=>mt_popups ASSIGNING FIELD-SYMBOL(<popup>).
      <popup>-parent = mo_window->mo_box.
      <popup>-child = mo_box.

      SET HANDLER on_box_close FOR mo_box.

      CREATE OBJECT mo_splitter
        EXPORTING
          parent  = mo_box
          rows    = 1
          columns = 2
        EXCEPTIONS
          OTHERS  = 1.

      mo_splitter->set_column_mode( mode = mo_splitter->mode_absolute ).
      mo_splitter->set_column_width( id = 1 width = mo_sel_width ).

      CALL METHOD:
       mo_splitter->get_container(  EXPORTING
          row       = 1
          column    = 1
        RECEIVING
          container = mo_sel_parent ),

        mo_splitter->get_container
         EXPORTING
          row       = 1
          column    = 2
         RECEIVING
          container = mo_alv_parent.

      SET HANDLER on_table_close FOR mo_box.


  endmethod.


  method CREATE_SEL_ALV.


      IF mo_sel IS INITIAL.
        mo_sel     = NEW #( io_viewer = me io_container = mo_sel_parent ).
        SET HANDLER refresh_table FOR mo_sel.
      ELSE.
        mo_sel->update_sel_tab( ).
      ENDIF.


  endmethod.


  method HANDLE_TAB_TOOLBAR.


      IF m_visible IS INITIAL.
        DATA(toolbar) = VALUE ttb_button(
         ( function = 'SEL_ON' icon = icon_arrow_left quickinfo = 'Show Select-Options'  butn_type = 0 )
         ( butn_type = 3 ) ).
      ENDIF.

      APPEND VALUE #( function = 'TECH' icon = icon_wd_caption quickinfo = 'Tech names'  butn_type = 0 ) TO toolbar.

      LOOP AT ZCL_ACE=>mt_lang INTO DATA(lang).
        IF sy-tabix > 10.
          EXIT.
        ENDIF.
        APPEND VALUE #( function = lang-spras icon = icon_foreign_trade quickinfo = lang-sptxt butn_type = 0 text = lang-sptxt ) TO toolbar.
      ENDLOOP.

      toolbar = VALUE ttb_button( BASE toolbar
       ( function = 'SHOW'  icon = icon_list  quickinfo = 'Show empty columns'   butn_type = 0  )
       ( function = 'TBAR' icon = COND #( WHEN m_std_tbar IS INITIAL THEN icon_column_right ELSE icon_column_left )
          quickinfo = COND #( WHEN m_std_tbar IS INITIAL THEN 'Show standard ALV function'  ELSE 'Hide standard ALV function') )
       ( butn_type = 3 ) ).

      IF m_std_tbar IS INITIAL.
        e_object->mt_toolbar =  toolbar.
      ELSE.
        e_object->mt_toolbar =  toolbar = VALUE ttb_button( BASE toolbar ( LINES OF e_object->mt_toolbar ) ).
      ENDIF.


  endmethod.


  method HANDLE_USER_COMMAND.


      DATA: it_fields  TYPE lvc_t_fcat,
            clause(45),
            sel_width  TYPE i.

      FIELD-SYMBOLS: <f_tab>  TYPE STANDARD  TABLE.
      ASSIGN mr_table->* TO <f_tab>.
      mo_alv->get_frontend_fieldcatalog( IMPORTING et_fieldcatalog = it_fields[] ).
      IF e_ucomm = 'SEL_ON' AND m_visible IS INITIAL.
        create_sel_alv( ).
        m_visible = abap_true.
        IF mo_sel_width = 0.
          sel_width = 500.
        ELSE.
          sel_width = mo_sel_width.
        ENDIF.

        mo_splitter->set_column_width( EXPORTING id = 1 width =  sel_width ).
        mo_alv->set_toolbar_interactive( ).
        RETURN.
      ELSEIF e_ucomm = 'TBAR'.
        m_std_tbar = BIT-NOT  m_std_tbar.
      ELSE.
        IF e_ucomm = 'SHOW'.
          IF m_show_empty IS INITIAL.
            m_show_empty = 1.
          ELSE.
            CLEAR m_show_empty.
          ENDIF.
        ENDIF.

        LOOP AT it_fields ASSIGNING FIELD-SYMBOL(<fields>) WHERE domname NE 'MANDT'.
          <fields>-col_pos = sy-tabix.
          CASE e_ucomm.

            WHEN 'SHOW'.
              IF m_show_empty = abap_false.
                <fields>-no_out = ' '.
              ELSE.
                clause = |{ <fields>-fieldname } IS NOT INITIAL|.
                LOOP AT <f_tab> ASSIGNING FIELD-SYMBOL(<f_line>)  WHERE (clause).
                  EXIT.
                ENDLOOP.
                IF sy-subrc NE 0.
                  <fields>-no_out = abap_true.
                ENDIF.
              ENDIF.

            WHEN 'TECH'. "technical field name
              <fields>-scrtext_l = <fields>-scrtext_m = <fields>-scrtext_s =  <fields>-reptext = <fields>-fieldname.

            WHEN OTHERS. "header names translation
              IF line_exists( ZCL_ACE=>mt_lang[ spras = e_ucomm ] ).
                translate_field( EXPORTING i_lang = CONV #( e_ucomm )  CHANGING c_fld = <fields> ).
                IF mo_sel IS BOUND.
                  READ TABLE mo_sel->mt_sel_tab ASSIGNING FIELD-SYMBOL(<sel>) WITH KEY field_label = <fields>-fieldname.
                  IF sy-subrc = 0.
                    IF <fields>-scrtext_l IS NOT INITIAL.
                      <sel>-name = <fields>-scrtext_l.
                    ENDIF.
                    IF <sel>-name IS INITIAL.
                      IF <fields>-reptext IS NOT INITIAL.
                        <sel>-name = <fields>-reptext.
                      ENDIF.
                    ENDIF.
                  ENDIF.
                ENDIF.
              ENDIF.
          ENDCASE.
        ENDLOOP.
      ENDIF.

      IF line_exists( ZCL_ACE=>mt_lang[ spras = e_ucomm ] ).
        m_lang = e_ucomm.
        set_header( ).
        mo_sel->set_value( i_field = 'SPRSL' i_low = m_lang ).
      ENDIF.

      CALL METHOD mo_alv->set_frontend_fieldcatalog EXPORTING it_fieldcatalog = it_fields[].

      ZCL_ACE_ALV_COMMON=>refresh( mo_alv ).
      IF mo_sel IS BOUND.
        IF  e_ucomm = 'HIDE' OR e_ucomm = 'SHOW' OR e_ucomm = 'UPDATE' .
          mo_sel->update_sel_tab( ).
        ENDIF.
        ZCL_ACE_ALV_COMMON=>refresh( mo_sel->mo_sel_alv ).
        mo_sel->mo_sel_alv->refresh_table_display(  ).
      ENDIF.


  endmethod.


  method ON_TABLE_CLOSE.

      DATA:  tabix LIKE sy-tabix.
      CALL METHOD sender->free
        EXCEPTIONS
          cntl_error = 1
          OTHERS     = 2.

      "Free Memory
      LOOP AT ZCL_ACE=>mt_obj ASSIGNING FIELD-SYMBOL(<obj>) WHERE alv_viewer IS NOT INITIAL.
        IF <obj>-alv_viewer->mo_box = sender.
          tabix = sy-tabix.
          EXIT.
        ENDIF.
      ENDLOOP.
      IF sy-subrc = 0.
        FREE <obj>-alv_viewer->mr_table.
        FREE <obj>-alv_viewer->mo_alv.

        FREE <obj>-alv_viewer.
        IF  tabix NE 0.
          DELETE ZCL_ACE=>mt_obj INDEX  tabix.
        ENDIF.
      ENDIF.


  endmethod.


  METHOD open_int_table.
    DATA r_tab TYPE REF TO data.
    IF it_ref IS BOUND. r_tab = it_ref. ELSE. GET REFERENCE OF it_tab INTO r_tab. ENDIF.
    APPEND INITIAL LINE TO zcl_ace=>mt_obj ASSIGNING FIELD-SYMBOL(<obj>).
    <obj>-alv_viewer = NEW zcl_ace_table_viewer( i_additional_name = i_name ir_tab = r_tab io_window = io_window ).
    <obj>-alv_viewer->mo_sel->raise_selection_done( ).
  ENDMETHOD.


  method REFRESH_TABLE.


      DATA: row    TYPE ZCL_ACE=>t_sel_row,
            filter TYPE lvc_t_filt.

      CLEAR filter.
      set_header( ).

      LOOP AT mo_sel->mt_sel_tab  ASSIGNING FIELD-SYMBOL(<sel>).
        LOOP AT <sel>-range INTO DATA(l_range).
          APPEND VALUE #( fieldname = <sel>-field_label
                                low = l_range-low
                               high = l_range-high
                               sign = l_range-sign
                             option = l_range-opti ) TO filter.
        ENDLOOP.
      ENDLOOP.

      IF mo_sel->mt_sel_tab IS NOT INITIAL.
        CALL METHOD mo_alv->set_filter_criteria
          EXPORTING
            it_filter = filter.
        ZCL_ACE_ALV_COMMON=>refresh( mo_sel->mo_sel_alv ).
        ZCL_ACE_ALV_COMMON=>refresh( mo_alv ).
        mo_sel->mo_viewer->handle_user_command( 'SHOW' ).

      ENDIF.

  endmethod.


  method SET_HEADER.


      DATA: text       TYPE as4text,
            header(80) TYPE c.

      SELECT SINGLE ddtext INTO  text
        FROM dd02t
       WHERE tabname = m_tabname
         AND ddlanguage = m_lang.

      header = |{ m_tabname } - {  text } { m_additional_name }|.
      mo_box->set_caption(  header ).


  endmethod.


  method TRANSLATE_FIELD.


      DATA: l_dd04 TYPE dd04v.

      READ TABLE mt_fields INTO DATA(l_field) WITH KEY field = c_fld-fieldname.
      CHECK l_field-elem IS NOT INITIAL.
      CLEAR l_dd04.

      CALL FUNCTION 'DDIF_DTEL_GET'
        EXPORTING
          name          = CONV ddobjname( l_field-elem )
          langu         = i_lang
        IMPORTING
          dd04v_wa      = l_dd04
        EXCEPTIONS
          illegal_input = 1
          OTHERS        = 2.

      IF sy-subrc = 0.
        IF l_dd04-reptext IS NOT INITIAL.
          MOVE-CORRESPONDING l_dd04 TO c_fld.
        ENDIF.
      ENDIF.


  endmethod.
ENDCLASS.
